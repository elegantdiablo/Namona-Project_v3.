// Admin Dashboard JavaScript

document.addEventListener("DOMContentLoaded", () => {
    checkAdminAccess();
    loadAllProducts();
    initEventListeners();
});

function initEventListeners() {
    const menuBtn = document.getElementById("menuButton");
    const sideMenu = document.getElementById("sideMenu");
    const content = document.getElementById("content");
    const profileBtn = document.querySelector(".profile-btn");
    
    menuBtn?.addEventListener("click", () => {
        sideMenu?.classList.toggle("open");
        content?.classList.toggle("shift");
    });

    profileBtn?.addEventListener("click", () => {
        document.getElementById("profileMenu")?.classList.toggle("open");
    });

    document.addEventListener("click", (e) => {
        const menu = document.getElementById("profileMenu");
        if (menu && profileBtn && !menu.contains(e.target) && !profileBtn.contains(e.target)) {
            menu.classList.remove("open");
        }
    });

    window.onclick = function(event) {
        const modal = document.getElementById("editModal");
        if (event.target == modal) {
            modal.style.display = "none";
        }
    };
}

async function checkAdminAccess() {
    try {
        const response = await fetch(API_URL + "/api/User/me", {
            credentials: "include"
        });

        if (!response.ok) {
            showAdminMessage("Not authorized. Please log in as admin.", "error");
            setTimeout(() => {
                window.location.href = "NamonaLogin.html";
            }, 2000);
            return;
        }

        const user = await response.json();
        if (user.role !== "Admin") {
            showAdminMessage("Access denied. Admin only.", "error");
            setTimeout(() => {
                window.location.href = "Namona.html";
            }, 2000);
            return;
        }

        const profileMenu = document.getElementById("profileMenu");
        if (profileMenu) {
            profileMenu.innerHTML = `
                <span>Welcome, ${user.userName}</span>
                <a href="#" onclick="logoutAdmin()">🚪 Logout</a>
            `;
        }
    } catch (error) {
        console.error("Error checking admin access:", error);
        showAdminMessage("Connection error. Please try again.", "error");
    }
}

function switchTab(tabName) {
    document.querySelectorAll(".tab-content").forEach(tab => {
        tab.classList.remove("active");
    });
    document.querySelectorAll(".admin-tab").forEach(tab => {
        tab.classList.remove("active");
    });

    document.getElementById(tabName).classList.add("active");
    event.target.classList.add("active");

    if (tabName === "list") {
        loadAllProducts();
    }
}

async function loadAllProducts() {
    const container = document.getElementById("productsContainer");
    container.innerHTML = '<div class="no-data">Loading products...</div>';

    try {
        const response = await fetch(API_URL + "/api/Clothes/GetAllClothes", {
            credentials: "include"
        });

        if (!response.ok) {
            container.innerHTML = '<div class="no-data">Failed to load products.</div>';
            return;
        }

        const products = await response.json();

        if (!Array.isArray(products) || products.length === 0) {
            container.innerHTML = '<div class="no-data">No products found.</div>';
            return;
        }

        let tableHTML = `
            <table class="products-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Category</th>
                        <th>Color</th>
                        <th>Size</th>
                        <th>Stock</th>
                        <th>Price</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
        `;

        products.forEach(product => {
            tableHTML += `
                <tr>
                    <td>${product.clothingId}</td>
                    <td>${product.clothingName || 'N/A'}</td>
                    <td>${product.categoryName || 'N/A'}</td>
                    <td>${product.color || 'N/A'}</td>
                    <td>${product.size || 'N/A'}</td>
                    <td>${product.stock || 0}</td>
                    <td>$${product.price || 0}</td>
                    <td>
                        <div class="table-actions">
                            <button class="btn-edit" onclick="openEditModal(${product.clothingId})">Edit</button>
                            <button class="btn-delete" onclick="deleteProduct(${product.clothingId})">Delete</button>
                        </div>
                    </td>
                </tr>
            `;
        });

        tableHTML += `
                </tbody>
            </table>
        `;

        container.innerHTML = tableHTML;
    } catch (error) {
        console.error("Error loading products:", error);
        container.innerHTML = '<div class="no-data">Error loading products. Please try again.</div>';
    }
}

async function openEditModal(clothingId) {
    try {
        const response = await fetch(API_URL + "/api/Clothes/GetAllClothes", {
            credentials: "include"
        });

        if (!response.ok) return;

        const products = await response.json();
        const product = products.find(p => p.clothingId === clothingId);

        if (!product) {
            showAdminMessage("Product not found.", "error");
            return;
        }

        document.getElementById("editProductId").value = product.clothingId;
        document.getElementById("editClothingName").value = product.clothingName || '';
        document.getElementById("editColor").value = product.color || '';
        document.getElementById("editSize").value = product.size || '';
        document.getElementById("editStock").value = product.stock || 0;
        document.getElementById("editPrice").value = product.price || 0;
        document.getElementById("editCollection").value = product.collection || '';
        document.getElementById("editImagePath").value = product.imagePath || '';

        document.getElementById("editModal").classList.add("show");
    } catch (error) {
        console.error("Error opening edit modal:", error);
        showAdminMessage("Error loading product details.", "error");
    }
}

function closeEditModal() {
    document.getElementById("editModal").classList.remove("show");
    document.getElementById("editProductForm").reset();
}

async function handleEditProduct(event) {
    event.preventDefault();

    const clothingId = parseInt(document.getElementById("editProductId").value);
    const clothingName = document.getElementById("editClothingName").value.trim();
    const color = document.getElementById("editColor").value.trim();
    const size = document.getElementById("editSize").value.trim();
    const stock = parseInt(document.getElementById("editStock").value);
    const price = parseFloat(document.getElementById("editPrice").value);
    const collection = document.getElementById("editCollection").value.trim();
    const imagePath = document.getElementById("editImagePath").value.trim();

    if (!clothingName || !color || !size || isNaN(stock) || isNaN(price)) {
        showAdminMessage("Please fill in all required fields.", "error");
        return;
    }

    try {
        const response = await fetch(API_URL + "/api/Clothes/modify", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            credentials: "include",
            body: JSON.stringify({
                clothingId: clothingId,
                clothingName: clothingName,
                color: color,
                size: size,
                stock: stock,
                price: price,
                collection: collection,
                imagePath: imagePath
            })
        });

        if (response.ok) {
            showAdminMessage("Product updated successfully!", "success");
            closeEditModal();
            loadAllProducts();
        } else {
            showAdminMessage("Failed to update product. Status: " + response.status, "error");
        }
    } catch (error) {
        console.error("Error updating product:", error);
        showAdminMessage("Connection error. Please try again.", "error");
    }
}

async function handleAddProduct(event) {
    event.preventDefault();

    const clothingName = document.getElementById("clothingName").value.trim();
    const color = document.getElementById("color").value.trim();
    const categoryId = parseInt(document.getElementById("categoryId").value);
    const genderId = parseInt(document.getElementById("genderId").value);
    const size = document.getElementById("size").value.trim();
    const stock = parseInt(document.getElementById("stock").value);
    const price = parseFloat(document.getElementById("price").value);
    const collection = document.getElementById("collection").value.trim();
    const imagePath = document.getElementById("imagePath").value.trim();

    // Get category and gender names
    const categoryNames = { 1: "T-Shirt", 2: "Hoodie", 3: "Pants" };
    const genderNames = { 1: "Male", 2: "Female", 3: "Unisex" };
    const categoryName = categoryNames[categoryId] || "";
    const genderName = genderNames[genderId] || "";

    if (!clothingName || !color || !categoryId || !genderId || !size || isNaN(stock) || isNaN(price)) {
        showAdminMessage("Please fill in all required fields.", "error");
        return;
    }

    try {
        const response = await fetch(API_URL + "/api/Clothes/AddClothes", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            credentials: "include",
            body: JSON.stringify({
                clothingName: clothingName,
                color: color,
                categoryId: categoryId,
                categoryName: categoryName,
                genderId: genderId,
                genderName: genderName,
                size: size,
                stock: stock,
                price: price,
                collection: collection,
                imagePath: imagePath
            })
        });

        if (response.ok || response.status === 201) {
            showAdminMessage("Product added successfully!", "success");
            document.getElementById("addProductForm").reset();
            switchTab("list");
        } else {
            const errorData = await response.json().catch(() => ({}));
            showAdminMessage("Failed to add product. Status: " + response.status, "error");
        }
    } catch (error) {
        console.error("Error adding product:", error);
        showAdminMessage("Connection error. Please try again.", "error");
    }
}

async function deleteProduct(clothingId) {
    if (!confirm("Are you sure you want to delete this product?")) {
        return;
    }

    try {
        const response = await fetch(API_URL + "/api/Clothes/remove?id=" + clothingId, {
            method: "DELETE",
            credentials: "include"
        });

        if (response.ok) {
            showAdminMessage("Product deleted successfully!", "success");
            loadAllProducts();
        } else {
            showAdminMessage("Failed to delete product. Status: " + response.status, "error");
        }
    } catch (error) {
        console.error("Error deleting product:", error);
        showAdminMessage("Connection error. Please try again.", "error");
    }
}

function updateCategoryName() {
    const categoryId = document.getElementById("categoryId").value;
    const categoryNames = { 1: "T-Shirt", 2: "Hoodie", 3: "Pants" };
    // This is used internally; the API expects the category name
}

function updateGenderName() {
    const genderId = document.getElementById("genderId").value;
    const genderNames = { 1: "Male", 2: "Female", 3: "Unisex" };
    // This is used internally; the API expects the gender name
}

function showAdminMessage(message, type) {
    const messageEl = document.getElementById("adminMessage");
    messageEl.textContent = message;
    messageEl.className = "message " + type;
    messageEl.style.display = "block";

    setTimeout(() => {
        messageEl.style.display = "none";
    }, 5000);
}

async function logoutAdmin() {
    try {
        await fetch(API_URL + "/api/User/logout", {
            method: "POST",
            credentials: "include"
        });
    } catch (error) {
        console.error("Logout error:", error);
    }

    window.location.href = "Namona.html";
}
